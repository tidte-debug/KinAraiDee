
import React, { useState } from 'react';
import { UserData, FortuneResult } from './types';
import { getFoodFortune, generateFoodImage } from './services/gemini';
import InputForm from './components/InputForm';
import ResultCard from './components/ResultCard';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<FortuneResult | null>(null);
  const [foodImage, setFoodImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleReveal = async (userData: UserData) => {
    setIsLoading(true);
    setError(null);
    try {
      const fortune = await getFoodFortune(userData.nickname, userData.birthDate);
      setResult(fortune);
      
      // Attempt to generate an image
      try {
        const image = await generateFoodImage(fortune.menuName);
        setFoodImage(image);
      } catch (imgError) {
        console.error("Failed to generate image:", imgError);
        setFoodImage(null);
      }
    } catch (err) {
      console.error(err);
      setError("ขออภัย ข้อมูลดวงชะตาติดขัด กรุณาลองใหม่อีกครั้ง");
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    setResult(null);
    setFoodImage(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#050810] text-slate-200 flex flex-col items-center p-6 md:p-12 relative overflow-hidden">
      {/* Ambient Background Lights */}
      <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-purple-900/20 blur-[150px] rounded-full"></div>
      <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-blue-900/20 blur-[150px] rounded-full"></div>

      {/* Header */}
      <header className="text-center mt-8 mb-20 relative z-10 animate-in fade-in slide-in-from-top-4 duration-1000">
        <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-white/5 border border-white/10 text-purple-400 text-[10px] font-bold mb-8 uppercase tracking-[0.3em]">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-purple-500"></span>
          </span>
          Digital Fortune Teller
        </div>
        <h1 className="text-6xl md:text-8xl font-mitr font-bold bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-purple-500/50 pb-4">
          วันนี้กินอะไรดี
        </h1>
        <div className="h-1 w-24 bg-gradient-to-r from-transparent via-purple-500 to-transparent mx-auto mb-6"></div>
        <p className="text-slate-400 max-w-md mx-auto text-lg font-light">
          ไขความลับดวงชะตาผ่านมื้ออาหารตามสั่ง <br/>
          ที่ออกแบบมาเพื่อคุณโดยเฉพาะ
        </p>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-5xl z-10 flex-grow flex items-start justify-center">
        {error ? (
          <div className="glass p-12 rounded-[2.5rem] text-center space-y-6 max-w-md border-red-500/20 shadow-2xl">
            <div className="text-red-400 text-6xl animate-bounce">🔮</div>
            <h3 className="text-2xl font-mitr text-white">เกิดข้อผิดพลาด</h3>
            <p className="text-slate-400">{error}</p>
            <button 
              onClick={reset} 
              className="w-full py-4 bg-white/5 hover:bg-white/10 rounded-2xl transition-all border border-white/10"
            >
              ลองใหม่อีกครั้ง
            </button>
          </div>
        ) : !result ? (
          <InputForm onSubmit={handleReveal} isLoading={isLoading} />
        ) : (
          <ResultCard result={result} imageUrl={foodImage} onReset={reset} />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-24 py-12 text-center text-slate-600 text-[10px] z-10 space-y-2 uppercase tracking-widest opacity-60">
        <p>© 2024 วันนี้กินอะไรดี • อาหารคือยาและดวงชะตา</p>
        <p>Intelligence Powered by Gemini 3.0</p>
      </footer>

      <style dangerouslySetInnerHTML={{ __html: `
        @import url('https://fonts.googleapis.com/css2?family=Mitr:wght@400;600&family=Sarabun:wght@200;400;700&display=swap');
        
        body {
          cursor: default;
          overflow-x: hidden;
        }

        .font-mitr { font-family: 'Mitr', sans-serif; }
        .font-sarabun { font-family: 'Sarabun', sans-serif; }

        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }

        select {
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='white'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'%3E%3C/path%3E%3C/svg%3E");
          background-repeat: no-repeat;
          background-position: right 1rem center;
          background-size: 1em;
        }

        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .animate-gradient {
          background-size: 200% 200%;
          animation: gradient 8s ease-infinite;
        }

        @keyframes shimmer-sweep {
          0% { transform: translateX(-100%) skewX(-15deg); }
          50% { transform: translateX(100%) skewX(-15deg); }
          100% { transform: translateX(100%) skewX(-15deg); }
        }
        .animate-shimmer-sweep {
          animation: shimmer-sweep 3s cubic-bezier(0.4, 0, 0.2, 1) infinite;
        }
      `}} />
    </div>
  );
};

export default App;
