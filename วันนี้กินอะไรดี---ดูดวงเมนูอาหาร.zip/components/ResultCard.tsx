
import React from 'react';
import { FortuneResult } from '../types';

interface ResultCardProps {
  result: FortuneResult;
  imageUrl: string | null;
  onReset: () => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, imageUrl, onReset }) => {
  return (
    <div className="w-full max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-1000">
      {/* Fortune Card Header */}
      <div className="relative group overflow-hidden rounded-[3rem] glass border-white/20 shadow-2xl">
        {/* Shimmer Overlay - Only visible when image is present */}
        {imageUrl && (
          <div className="absolute inset-0 z-15 pointer-events-none overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full animate-shimmer-sweep"></div>
          </div>
        )}
        
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent z-10"></div>
        
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={result.menuName} 
            className="w-full aspect-square md:aspect-[16/10] object-cover transition-transform duration-[2s] group-hover:scale-105" 
          />
        ) : (
          <div className="w-full aspect-square md:aspect-[16/10] bg-indigo-950/50 flex flex-col items-center justify-center gap-4">
            <div className="w-12 h-12 border-2 border-purple-500/30 border-t-purple-500 rounded-full animate-spin"></div>
            <p className="text-purple-300/50 font-mitr text-sm">กำลังวาดภาพเมนูมงคล...</p>
          </div>
        )}

        <div className="absolute bottom-0 left-0 right-0 p-8 z-20 space-y-2">
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-full bg-purple-500 text-[10px] font-bold text-white uppercase tracking-widest shadow-lg shadow-purple-500/50">
              ธาตุ{result.element}
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl font-mitr font-bold text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.5)]">
            {result.menuName}
          </h2>
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 glass rounded-[2rem] p-8 space-y-6 border-white/5 bg-white/[0.02]">
          <div>
            <h3 className="text-purple-400 font-mitr font-semibold mb-2 flex items-center gap-2 text-lg">
              <span className="text-2xl">🍽️</span> มงคลแห่งมื้อนี้
            </h3>
            <p className="text-slate-300 leading-relaxed font-light">{result.description}</p>
          </div>
          <div className="pt-6 border-t border-white/10">
            <h3 className="text-purple-400 font-mitr font-semibold mb-2 flex items-center gap-2 text-lg">
              <span className="text-2xl">🔮</span> เคล็ดลับเสริมดวง
            </h3>
            <p className="text-indigo-200/90 leading-relaxed italic font-light">"{result.reason}"</p>
          </div>
        </div>

        <div className="glass rounded-[2rem] p-8 flex flex-col items-center justify-center text-center bg-gradient-to-br from-purple-900/20 to-indigo-900/20 border-purple-500/20">
          <h3 className="text-yellow-400 font-mitr font-semibold mb-6 text-sm uppercase tracking-widest">
            เลขนำโชค
          </h3>
          <div className="flex flex-col gap-4">
            {result.luckyNumbers.map((num, i) => (
              <div 
                key={i} 
                className="w-16 h-16 rounded-2xl bg-gradient-to-br from-yellow-300 to-yellow-600 flex items-center justify-center text-slate-950 font-bold text-2xl shadow-xl shadow-yellow-500/20 transform hover:scale-110 transition-transform cursor-default"
              >
                {num}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex justify-center pt-4">
        <button
          onClick={onReset}
          className="px-10 py-4 rounded-full bg-white/5 hover:bg-white/10 text-purple-300 hover:text-white transition-all border border-white/10 text-sm font-mitr"
        >
          กลับไปทำนายใหม่
        </button>
      </div>
    </div>
  );
};

export default ResultCard;
