
import React from 'react';
import { UserData } from '../types';

interface InputFormProps {
  onSubmit: (data: UserData) => void;
  isLoading: boolean;
}

const InputForm: React.FC<InputFormProps> = ({ onSubmit, isLoading }) => {
  const [nickname, setNickname] = React.useState('');
  const [day, setDay] = React.useState('1');
  const [month, setMonth] = React.useState('มกราคม');
  const [year, setYear] = React.useState('');

  const months = [
    "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
    "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (nickname && year) {
      const fullBirthDate = `${day} ${month} พ.ศ. ${year}`;
      onSubmit({ nickname, birthDate: fullBirthDate });
    }
  };

  return (
    <div className="w-full max-w-md mx-auto animate-in fade-in zoom-in duration-500">
      <form onSubmit={handleSubmit} className="glass p-8 rounded-[2.5rem] space-y-8 border-white/10 shadow-2xl">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-mitr font-semibold text-white">กรอกข้อมูลดวงชะตา</h2>
          <p className="text-purple-300/70 text-sm">ข้อมูลของคุณจะถูกใช้เพื่อทำนายเมนูที่เหมาะสมที่สุด</p>
        </div>

        <div className="space-y-4">
          <div className="group">
            <label className="block text-purple-200 text-xs font-bold mb-2 ml-1 uppercase tracking-widest">ชื่อเล่น</label>
            <input
              required
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              placeholder="กรอกชื่อเล่นของคุณ"
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all placeholder:text-slate-500"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-purple-200 text-xs font-bold mb-2 ml-1 uppercase tracking-widest">วันเกิด (พ.ศ.)</label>
            <div className="grid grid-cols-12 gap-2">
              <select
                value={day}
                onChange={(e) => setDay(e.target.value)}
                className="col-span-3 bg-white/5 border border-white/10 rounded-2xl px-2 py-4 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 appearance-none text-center cursor-pointer"
              >
                {Array.from({ length: 31 }, (_, i) => (
                  <option key={i + 1} value={i + 1} className="bg-slate-900">{i + 1}</option>
                ))}
              </select>
              <select
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="col-span-5 bg-white/5 border border-white/10 rounded-2xl px-2 py-4 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 appearance-none text-center cursor-pointer"
              >
                {months.map((m) => (
                  <option key={m} value={m} className="bg-slate-900">{m}</option>
                ))}
              </select>
              <input
                required
                type="number"
                placeholder="25XX"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="col-span-4 bg-white/5 border border-white/10 rounded-2xl px-2 py-4 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 text-center placeholder:text-slate-500"
                min="2450"
                max="2570"
              />
            </div>
          </div>
        </div>

        <button
          disabled={isLoading}
          type="submit"
          className={`w-full py-5 rounded-2xl font-mitr text-xl font-bold transition-all transform active:scale-[0.97] relative overflow-hidden group ${
            isLoading 
            ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
            : 'bg-gradient-to-br from-indigo-600 to-purple-700 text-white shadow-[0_0_20px_rgba(139,92,246,0.3)] hover:shadow-[0_0_30px_rgba(139,92,246,0.5)]'
          }`}
        >
          {isLoading ? (
            <div className="flex items-center justify-center gap-3">
              <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
              <span>กำลังตรวจสอบดวง...</span>
            </div>
          ) : (
            <>
              <span className="relative z-10">เปิดตำราทำนาย</span>
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
            </>
          )}
        </button>
      </form>
      <div className="mt-8 text-center text-slate-500 text-xs flex items-center justify-center gap-2">
        <span className="w-8 h-[1px] bg-slate-800"></span>
        ศาสตร์การกินเสริมดวงแห่งยุคดิจิทัล
        <span className="w-8 h-[1px] bg-slate-800"></span>
      </div>
    </div>
  );
};

export default InputForm;
