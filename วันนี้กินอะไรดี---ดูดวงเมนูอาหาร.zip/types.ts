
export interface FortuneResult {
  menuName: string;
  description: string;
  reason: string;
  luckyNumbers: string[];
  element: string;
}

export interface UserData {
  nickname: string;
  birthDate: string;
}
