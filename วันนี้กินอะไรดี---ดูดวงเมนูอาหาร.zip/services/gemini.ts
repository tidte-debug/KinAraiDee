
import { GoogleGenAI, Type } from "@google/genai";
import { FortuneResult } from "../types";

export const getFoodFortune = async (nickname: string, birthDate: string): Promise<FortuneResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  // birthDate will be passed as "15 มกราคม 2535"
  const prompt = `คุณคือ "ซินแสอาหารตามสั่ง" ผู้เชี่ยวชาญการพยากรณ์ดวงชะตาผ่านมื้ออาหาร 
  ทำนายดวงของคนชื่อ "${nickname}" เกิดเมื่อวันที่ "${birthDate}" (ปี พ.ศ.) 
  
  ช่วยแนะนำ "เมนูอาหารตามสั่งไทยง่ายๆ" 1 เมนู (เช่น กะเพรา, ผัดซีอิ๊ว, ข้าวผัด, ก๋วยเตี๋ยวเรือ, ราดหน้า, ข้าวมันไก่) 
  ที่กินแล้วจะเสริมสิริมงคล เสริมโชคลาภ หรือแก้เคล็ดในวันนี้
  
  ตอบเป็น JSON ตามโครงสร้างนี้:
  1. menuName: ชื่อเมนูภาษาไทยสั้นๆ
  2. description: คำบรรยายเมนูที่น่ากิน
  3. reason: เหตุผลทางโหราศาสตร์ที่เมนูนี้ช่วยเสริมดวง (เช่น เสริมบารมีด้วยพริกสีแดง หรือ เสริมความลื่นไหลด้วยเส้นก๋วยเตี๋ยว)
  4. luckyNumbers: เลขนำโชค 3 ตัวที่เด่นที่สุดสำหรับคนนี้ในวันนี้
  5. element: ธาตุที่เกี่ยวข้อง (ดิน, น้ำ, ลม, ไฟ, หรือ ทอง)
  
  ใช้ภาษาที่สุภาพ เป็นกันเอง และดูมีความเป็นมงคล`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          menuName: { type: Type.STRING },
          description: { type: Type.STRING },
          reason: { type: Type.STRING },
          luckyNumbers: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING } 
          },
          element: { type: Type.STRING }
        },
        required: ["menuName", "description", "reason", "luckyNumbers", "element"]
      }
    }
  });

  return JSON.parse(response.text.trim());
};

export const generateFoodImage = async (menuName: string): Promise<string | null> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { text: `A mouth-watering, high-quality, professional street food photo of ${menuName} on a typical Thai plastic or ceramic plate, street food atmosphere, cinematic lighting, bokeh background.` }
      ]
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1"
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
};
